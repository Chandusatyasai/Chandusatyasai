# Blood Group Detection System

A production-ready web application for blood group detection using Convolutional Neural Networks (CNN) and advanced image processing techniques.

## Features

### Core Functionality
- **AI-Powered Blood Type Analysis**: Simulated CNN model for detecting blood groups (A, B, AB, O) and Rh factors (+/-)
- **Real-time Image Processing**: Upload and analyze blood sample images instantly
- **Confidence Scoring**: Get confidence levels for each detection
- **Patient Management**: Store patient information with each detection

### Analytics & History
- **Detection History**: Complete record of all blood sample analyses
- **Analytics Dashboard**: Visual insights into detection patterns
- **Blood Group Distribution**: Statistical breakdown of detected blood types
- **Performance Metrics**: Average confidence scores and processing times

### Security & Authentication
- **Secure Authentication**: Email/password authentication via Supabase
- **Row Level Security**: Database-level security for all user data
- **Secure Image Storage**: Images stored in Supabase Storage with proper access control
- **User Profiles**: Role-based access (Admin, Doctor, Lab Technician, User)

## Technology Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Storage**: Supabase Storage
- **Icons**: Lucide React
- **Build Tool**: Vite

## Database Schema

### Tables

#### `profiles`
User profile information extending Supabase auth.users
- Links to authentication system
- Stores user role and organization
- Enables role-based access control

#### `blood_detections`
Core detection records
- Patient information (name, age, gender)
- Detection results (blood group, Rh factor)
- Confidence scores and processing metrics
- Status tracking (pending, completed, verified, rejected)
- Notes and observations

#### `detection_metadata`
Technical analysis metadata
- Image quality assessments
- Preprocessing steps applied
- Model version tracking
- Feature vectors for analysis

## CNN Simulation

The application includes a sophisticated CNN simulator that mimics real blood group detection:

### Image Processing Pipeline
1. **Image Normalization**: Standardize input images
2. **Noise Reduction**: Gaussian blur filtering
3. **Contrast Enhancement**: CLAHE (Contrast Limited Adaptive Histogram Equalization)
4. **Edge Detection**: Canny edge detection
5. **Color Space Conversion**: RGB to LAB color space
6. **Feature Extraction**: HOG (Histogram of Oriented Gradients)

### Feature Analysis
- Red cell density measurement
- Agglutination pattern detection
- Cell morphology analysis
- Color intensity evaluation
- Texture complexity assessment
- Spatial distribution mapping

### Classification Logic
The simulator uses extracted features to classify blood groups:
- High agglutination + high cell density → AB
- Moderate agglutination → A or B
- Low agglutination → O
- Rh factor determined independently
- Confidence scores adjusted based on image quality

## Setup Instructions

### Prerequisites
- Node.js 18+ installed
- Supabase account

### Database Setup

1. Go to your Supabase project SQL Editor
2. Copy and run the SQL from `setup-database.sql`
3. Create a storage bucket named `blood-samples` in Supabase Storage
4. Set the bucket to private (authentication required)

### Application Setup

1. Install dependencies:
```bash
npm install
```

2. Environment variables are already configured in `.env`

3. Start the development server:
```bash
npm run dev
```

4. Build for production:
```bash
npm run build
```

## Usage Guide

### First Time Setup
1. Open the application in your browser
2. Click "Sign Up" to create an account
3. Enter your full name, email, and password
4. You'll be automatically logged in

### Analyzing Blood Samples

1. **Upload Image**
   - Click the upload area on the detection form
   - Select a blood sample image (JPEG, PNG, or WebP, max 10MB)
   - The image will preview immediately

2. **Enter Patient Information**
   - Patient Name (required)
   - Age (optional)
   - Gender (optional)
   - Notes (optional observations)

3. **Analyze**
   - Click "Analyze Blood Sample"
   - Processing takes 1-2 seconds
   - Results display with confidence score

4. **View Results**
   - Blood Group (A, B, AB, or O)
   - Rh Factor (+ or -)
   - Confidence Score (percentage)
   - Processing Time
   - Image Quality Score

### Viewing History
- All detections are saved automatically
- Click any record to view full details
- See patient information and sample images
- Review detection confidence and metadata

### Analytics Dashboard
- Total detections count
- Average confidence score
- Average processing time
- Most common blood group
- Blood group distribution chart

## Replacing the Simulated CNN

To integrate a real CNN model:

### Option 1: Client-Side Model (TensorFlow.js)

1. Install TensorFlow.js:
```bash
npm install @tensorflow/tfjs
```

2. Update `src/lib/cnnSimulator.ts`:
```typescript
import * as tf from '@tensorflow/tfjs';

export class CNNModel {
  private model: tf.LayersModel | null = null;

  async loadModel() {
    this.model = await tf.loadLayersModel('/path/to/model.json');
  }

  async analyzeImage(imageFile: File): Promise<BloodGroupResult> {
    // Preprocess image
    const tensor = await this.preprocessImage(imageFile);

    // Run inference
    const prediction = this.model!.predict(tensor) as tf.Tensor;

    // Post-process results
    return this.postprocessPrediction(prediction);
  }
}
```

### Option 2: Server-Side Model (Python API)

1. Create a Python FastAPI/Flask backend with your trained model
2. Update `src/lib/cnnSimulator.ts` to call your API:
```typescript
async analyzeImage(imageFile: File): Promise<BloodGroupResult> {
  const formData = new FormData();
  formData.append('image', imageFile);

  const response = await fetch('https://your-api.com/detect', {
    method: 'POST',
    body: formData,
  });

  return await response.json();
}
```

### Option 3: Edge Function

Deploy your model as a Supabase Edge Function for serverless inference.

## Security Considerations

### Data Protection
- All user data is protected by Row Level Security (RLS)
- Users can only access their own detections
- Images are stored in private storage buckets
- Authentication required for all operations

### Best Practices
- Never expose API keys in client code
- Validate all file uploads
- Sanitize user inputs
- Use HTTPS in production
- Regular security audits recommended

## Model Training Guide

To train your own CNN model for blood group detection:

### Dataset Requirements
- Labeled blood sample images
- Multiple samples per blood group
- High-resolution microscopic images
- Proper lighting and focus
- Balanced dataset across all blood types

### Recommended Architecture
- Input: 224x224 RGB images
- Convolutional layers with batch normalization
- MaxPooling for dimensionality reduction
- Dropout for regularization
- Dense layers for classification
- Softmax output for blood group classes

### Training Tips
- Data augmentation (rotation, flip, zoom)
- Transfer learning from pre-trained models (ResNet, VGG)
- Cross-validation for robust evaluation
- Monitor validation accuracy
- Save best model checkpoints

## Performance Optimization

### Frontend
- Lazy loading for images
- Component code splitting
- Memoization for expensive calculations
- Debounced search and filters

### Backend
- Database indexing on frequently queried columns
- Efficient RLS policies
- Optimized image storage
- CDN for static assets

## Troubleshooting

### Common Issues

**"Missing Supabase environment variables"**
- Check `.env` file exists
- Verify VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set
- Restart dev server after changes

**"Failed to upload image"**
- Check Supabase storage bucket exists
- Verify bucket name is "blood-samples"
- Check storage policies are configured
- Ensure user is authenticated

**"Cannot read detections"**
- Verify RLS policies are applied
- Check user is authenticated
- Confirm database tables exist
- Review browser console for errors

## Contributing

This is a production-ready template. To extend:

1. Add more blood tests (hemoglobin, platelet count, etc.)
2. Implement report generation and PDF export
3. Add multi-language support
4. Create mobile app version
5. Integrate with hospital management systems

## License

This project is provided as-is for educational and commercial use.

## Support

For medical use, ensure compliance with:
- HIPAA (US)
- GDPR (EU)
- Local healthcare regulations
- Medical device certifications

Always validate AI predictions with manual verification by qualified medical professionals.
