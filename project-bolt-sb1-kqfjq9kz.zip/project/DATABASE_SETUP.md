# Database Setup Instructions

## Quick Setup

Follow these steps to set up the database for the Blood Group Detection System:

### Step 1: Access Supabase SQL Editor

1. Go to your Supabase project dashboard
2. Click on "SQL Editor" in the left sidebar
3. Click "New Query"

### Step 2: Run the Setup SQL

1. Open the file `setup-database.sql` in this project
2. Copy all the SQL code
3. Paste it into the Supabase SQL Editor
4. Click "Run" or press Ctrl/Cmd + Enter

This will create:
- `profiles` table for user information
- `blood_detections` table for detection records
- `detection_metadata` table for technical analysis data
- All necessary indexes for performance
- Row Level Security (RLS) policies for data protection

### Step 3: Create Storage Bucket

1. Go to "Storage" in the Supabase sidebar
2. Click "Create a new bucket"
3. Name it: `blood-samples`
4. Set it to **Private** (not public)
5. Click "Create bucket"

The storage policies for this bucket are already included in the SQL setup script.

### Step 4: Verify Setup

Run this query to verify tables were created:

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = 'public'
AND table_name IN ('profiles', 'blood_detections', 'detection_metadata');
```

You should see all three tables listed.

### Step 5: Test RLS Policies

Sign up for an account in the application, then run:

```sql
SELECT * FROM profiles WHERE id = auth.uid();
```

This should return your profile data, confirming RLS is working.

## Manual Setup (Alternative)

If you prefer to create tables one at a time:

### Create Profiles Table

```sql
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  role text NOT NULL DEFAULT 'user',
  organization text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);
```

### Create Blood Detections Table

```sql
CREATE TABLE blood_detections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_name text NOT NULL,
  patient_age integer,
  patient_gender text,
  image_url text NOT NULL,
  blood_group text NOT NULL,
  rh_factor text NOT NULL,
  confidence_score decimal(5,2),
  processing_time_ms integer DEFAULT 0,
  notes text,
  status text NOT NULL DEFAULT 'completed',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE blood_detections ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own detections"
  ON blood_detections FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);
```

### Create Detection Metadata Table

```sql
CREATE TABLE detection_metadata (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  detection_id uuid NOT NULL REFERENCES blood_detections(id) ON DELETE CASCADE,
  image_quality_score decimal(5,2),
  preprocessing_steps jsonb DEFAULT '[]'::jsonb,
  model_version text DEFAULT 'v1.0.0',
  feature_vectors jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE detection_metadata ENABLE ROW LEVEL SECURITY;
```

## Troubleshooting

### "permission denied for table profiles"

The RLS policies need to be applied. Make sure you ran the policy creation statements.

### "relation 'profiles' does not exist"

The table wasn't created. Check for SQL errors in the Supabase SQL Editor.

### "function auth.uid() does not exist"

You're running the query as an unauthenticated user. Use the application's authentication system.

### Storage bucket issues

1. Verify bucket name is exactly `blood-samples`
2. Ensure bucket is set to Private
3. Check that storage policies were created
4. Try re-running the storage policy SQL

## Database Schema Diagram

```
auth.users (Supabase built-in)
    │
    └─── profiles
         └─── id (FK to auth.users.id)

auth.users
    │
    └─── blood_detections
         ├─── id
         ├─── user_id (FK to auth.users.id)
         └─── detection_metadata
              └─── detection_id (FK to blood_detections.id)
```

## Row Level Security

All tables have RLS enabled with these rules:

- **Profiles**: Users can only view and edit their own profile
- **Blood Detections**: Users can only access their own detection records
- **Detection Metadata**: Users can only view metadata for their own detections

This ensures complete data isolation between users.

## Performance Considerations

The setup includes indexes on:
- `blood_detections.user_id` - Fast user-specific queries
- `blood_detections.status` - Quick status filtering
- `blood_detections.created_at` - Efficient chronological sorting
- `detection_metadata.detection_id` - Fast metadata lookups

These indexes significantly improve query performance as data grows.

## Data Retention

Consider adding a data retention policy:

```sql
-- Delete detections older than 1 year (example)
DELETE FROM blood_detections
WHERE created_at < NOW() - INTERVAL '1 year';
```

Set up a scheduled job in Supabase for automatic cleanup.

## Backup Recommendations

1. Use Supabase's automatic backups (available on paid plans)
2. Export data regularly using SQL:

```sql
COPY blood_detections TO '/path/to/backup.csv' CSV HEADER;
```

3. Download images from storage bucket periodically

## Next Steps

After database setup:

1. Start the application: `npm run dev`
2. Sign up for an account
3. Upload a blood sample image
4. View your detection history and analytics
5. Check the database to see your data

For production deployment, ensure:
- Database backups are enabled
- Monitoring is set up
- Usage limits are appropriate
- RLS policies are tested thoroughly
