import { useState, useEffect } from 'react';
import { Activity, Clock, TrendingUp, Users } from 'lucide-react';
import { supabase, BloodDetection } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { StatsCard } from './StatsCard';

type AnalyticsDashboardProps = {
  refresh: number;
};

export const AnalyticsDashboard = ({ refresh }: AnalyticsDashboardProps) => {
  const { user } = useAuth();
  const [detections, setDetections] = useState<BloodDetection[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDetections();
    }
  }, [user, refresh]);

  const fetchDetections = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('blood_detections')
      .select('*')
      .eq('user_id', user?.id);

    if (!error && data) {
      setDetections(data);
    }
    setLoading(false);
  };

  const totalDetections = detections.length;
  const avgConfidence = detections.length > 0
    ? detections.reduce((sum, d) => sum + d.confidence_score, 0) / detections.length
    : 0;
  const avgProcessingTime = detections.length > 0
    ? detections.reduce((sum, d) => sum + d.processing_time_ms, 0) / detections.length
    : 0;

  const bloodGroupDistribution = detections.reduce((acc, d) => {
    const key = `${d.blood_group}${d.rh_factor}`;
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const mostCommon = Object.entries(bloodGroupDistribution).sort((a, b) => b[1] - a[1])[0];

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-white rounded-xl shadow-lg p-6 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
            <div className="h-8 bg-gray-200 rounded w-3/4"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatsCard
          title="Total Detections"
          value={totalDetections}
          icon={Activity}
          color="bg-red-600"
          subtitle="All time"
        />
        <StatsCard
          title="Avg Confidence"
          value={`${avgConfidence.toFixed(1)}%`}
          icon={TrendingUp}
          color="bg-green-600"
          subtitle={avgConfidence >= 90 ? 'Excellent' : 'Good'}
        />
        <StatsCard
          title="Avg Processing"
          value={`${Math.round(avgProcessingTime)}ms`}
          icon={Clock}
          color="bg-blue-600"
          subtitle="Per detection"
        />
        <StatsCard
          title="Most Common"
          value={mostCommon ? mostCommon[0] : 'N/A'}
          icon={Users}
          color="bg-orange-600"
          subtitle={mostCommon ? `${mostCommon[1]} samples` : 'No data'}
        />
      </div>

      {totalDetections > 0 && (
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">
            Blood Group Distribution
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(bloodGroupDistribution)
              .sort((a, b) => b[1] - a[1])
              .map(([group, count]) => {
                const percentage = ((count / totalDetections) * 100).toFixed(1);
                return (
                  <div
                    key={group}
                    className="bg-gradient-to-br from-red-50 to-pink-50 rounded-lg p-4 border border-red-100"
                  >
                    <p className="text-2xl font-bold text-red-600 mb-1">{group}</p>
                    <p className="text-sm text-gray-600">
                      {count} samples ({percentage}%)
                    </p>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
};
