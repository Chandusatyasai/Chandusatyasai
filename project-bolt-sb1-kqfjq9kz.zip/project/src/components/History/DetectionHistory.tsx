import { useState, useEffect } from 'react';
import { Calendar, User, Clock, TrendingUp, FileText } from 'lucide-react';
import { supabase, BloodDetection } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

type DetectionHistoryProps = {
  refresh: number;
};

export const DetectionHistory = ({ refresh }: DetectionHistoryProps) => {
  const { user } = useAuth();
  const [detections, setDetections] = useState<BloodDetection[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDetection, setSelectedDetection] = useState<BloodDetection | null>(null);

  useEffect(() => {
    if (user) {
      fetchDetections();
    }
  }, [user, refresh]);

  const fetchDetections = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('blood_detections')
      .select('*')
      .eq('user_id', user?.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setDetections(data);
    }
    setLoading(false);
  };

  const getBloodGroupColor = (bloodGroup: string) => {
    const colors: Record<string, string> = {
      A: 'bg-blue-100 text-blue-800',
      B: 'bg-green-100 text-green-800',
      AB: 'bg-purple-100 text-purple-800',
      O: 'bg-orange-100 text-orange-800',
    };
    return colors[bloodGroup] || 'bg-gray-100 text-gray-800';
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 95) return 'text-green-600';
    if (confidence >= 85) return 'text-yellow-600';
    return 'text-orange-600';
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
          <div className="h-20 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-gray-900">Detection History</h2>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-red-50 rounded-lg">
          <FileText className="w-4 h-4 text-red-600" />
          <span className="text-sm font-medium text-red-900">
            {detections.length} Records
          </span>
        </div>
      </div>

      {detections.length === 0 ? (
        <div className="text-center py-12">
          <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-600 font-medium">No detection records yet</p>
          <p className="text-sm text-gray-500 mt-1">
            Upload and analyze your first blood sample to get started
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {detections.map((detection) => (
            <div
              key={detection.id}
              onClick={() => setSelectedDetection(detection)}
              className="border border-gray-200 rounded-lg p-4 hover:border-red-300 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-bold ${getBloodGroupColor(
                        detection.blood_group
                      )}`}
                    >
                      {detection.blood_group}
                      {detection.rh_factor}
                    </span>
                    <span
                      className={`text-sm font-semibold ${getConfidenceColor(
                        detection.confidence_score
                      )}`}
                    >
                      {detection.confidence_score.toFixed(1)}% confidence
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <User className="w-4 h-4" />
                      <span className="font-medium">{detection.patient_name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar className="w-4 h-4" />
                      <span>
                        {new Date(detection.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    {detection.patient_age && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <TrendingUp className="w-4 h-4" />
                        <span>{detection.patient_age} years</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>{detection.processing_time_ms}ms</span>
                    </div>
                  </div>

                  {detection.notes && (
                    <p className="mt-2 text-sm text-gray-600 italic">
                      {detection.notes}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedDetection && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedDetection(null)}
        >
          <div
            className="bg-white rounded-xl max-w-2xl w-full p-6"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Detection Details
            </h3>

            <div className="space-y-4">
              <img
                src={selectedDetection.image_url}
                alt="Blood sample"
                className="w-full h-64 object-contain bg-gray-50 rounded-lg"
              />

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Patient Name</p>
                  <p className="font-semibold text-gray-900">
                    {selectedDetection.patient_name}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Blood Group</p>
                  <p className="font-semibold text-gray-900 text-xl">
                    {selectedDetection.blood_group}
                    {selectedDetection.rh_factor}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Confidence Score</p>
                  <p className="font-semibold text-gray-900">
                    {selectedDetection.confidence_score.toFixed(2)}%
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Processing Time</p>
                  <p className="font-semibold text-gray-900">
                    {selectedDetection.processing_time_ms}ms
                  </p>
                </div>
                {selectedDetection.patient_age && (
                  <div>
                    <p className="text-sm text-gray-600">Age</p>
                    <p className="font-semibold text-gray-900">
                      {selectedDetection.patient_age} years
                    </p>
                  </div>
                )}
                {selectedDetection.patient_gender && (
                  <div>
                    <p className="text-sm text-gray-600">Gender</p>
                    <p className="font-semibold text-gray-900 capitalize">
                      {selectedDetection.patient_gender}
                    </p>
                  </div>
                )}
                <div className="col-span-2">
                  <p className="text-sm text-gray-600">Date</p>
                  <p className="font-semibold text-gray-900">
                    {new Date(selectedDetection.created_at).toLocaleString()}
                  </p>
                </div>
                {selectedDetection.notes && (
                  <div className="col-span-2">
                    <p className="text-sm text-gray-600">Notes</p>
                    <p className="text-gray-900">{selectedDetection.notes}</p>
                  </div>
                )}
              </div>

              <button
                onClick={() => setSelectedDetection(null)}
                className="w-full bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 rounded-lg transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
