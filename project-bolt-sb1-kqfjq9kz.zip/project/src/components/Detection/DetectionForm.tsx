import { useState, useRef } from 'react';
import { Upload, X, Loader2, CheckCircle, Image as ImageIcon } from 'lucide-react';
import { validateImageFile, processImage } from '../../lib/imageProcessing';
import { cnnSimulator, BloodGroupResult } from '../../lib/cnnSimulator';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

type DetectionFormProps = {
  onDetectionComplete: () => void;
};

export const DetectionForm = ({ onDetectionComplete }: DetectionFormProps) => {
  const { user } = useAuth();
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [patientGender, setPatientGender] = useState<'male' | 'female' | 'other'>('male');
  const [notes, setNotes] = useState('');
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState<BloodGroupResult | null>(null);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validation = validateImageFile(file);
    if (!validation.valid) {
      setError(validation.error || 'Invalid file');
      return;
    }

    setError('');
    setImageFile(file);

    try {
      const preview = await processImage(file);
      setImagePreview(preview);
    } catch (err) {
      setError('Failed to load image preview');
    }
  };

  const handleAnalyze = async () => {
    if (!imageFile || !patientName || !user) return;

    setProcessing(true);
    setError('');

    try {
      const analysisResult = await cnnSimulator.analyzeImage(imageFile);
      setResult(analysisResult);

      const fileName = `${user.id}/${Date.now()}_${imageFile.name}`;
      const { error: uploadError } = await supabase.storage
        .from('blood-samples')
        .upload(fileName, imageFile);

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('blood-samples')
        .getPublicUrl(fileName);

      const { error: insertError } = await supabase.from('blood_detections').insert({
        user_id: user.id,
        patient_name: patientName,
        patient_age: patientAge ? parseInt(patientAge) : null,
        patient_gender: patientGender,
        image_url: urlData.publicUrl,
        blood_group: analysisResult.bloodGroup,
        rh_factor: analysisResult.rhFactor,
        confidence_score: analysisResult.confidence,
        processing_time_ms: analysisResult.processingTime,
        notes: notes || null,
        status: 'completed',
      });

      if (insertError) throw insertError;

      onDetectionComplete();
    } catch (err: any) {
      setError(err.message || 'Failed to analyze image');
    } finally {
      setProcessing(false);
    }
  };

  const handleReset = () => {
    setImageFile(null);
    setImagePreview(null);
    setPatientName('');
    setPatientAge('');
    setPatientGender('male');
    setNotes('');
    setResult(null);
    setError('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-6">New Blood Sample Analysis</h2>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-800">
          {error}
        </div>
      )}

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Blood Sample Image
          </label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 hover:border-red-400 transition-colors">
            {!imagePreview ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="cursor-pointer text-center"
              >
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-sm font-medium text-gray-900 mb-1">
                  Click to upload blood sample image
                </p>
                <p className="text-xs text-gray-500">PNG, JPG or WebP (max 10MB)</p>
              </div>
            ) : (
              <div className="relative">
                <img
                  src={imagePreview}
                  alt="Preview"
                  className="w-full h-64 object-contain rounded-lg"
                />
                <button
                  onClick={handleReset}
                  className="absolute top-2 right-2 p-1.5 bg-red-600 hover:bg-red-700 text-white rounded-full transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/jpg,image/png,image/webp"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>
        </div>

        {imagePreview && !result && (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Patient Name *
              </label>
              <input
                type="text"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Age
              </label>
              <input
                type="number"
                value={patientAge}
                onChange={(e) => setPatientAge(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
                placeholder="25"
                min="1"
                max="150"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Gender
              </label>
              <select
                value={patientGender}
                onChange={(e) => setPatientGender(e.target.value as any)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none resize-none"
                placeholder="Additional observations..."
              />
            </div>
          </div>
        )}

        {result && (
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg p-6 border-2 border-green-200">
            <div className="flex items-center gap-2 mb-4">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <h3 className="text-lg font-bold text-gray-900">Detection Complete</h3>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="bg-white rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Blood Group</p>
                <p className="text-3xl font-bold text-red-600">
                  {result.bloodGroup}
                  <span className="text-2xl">{result.rhFactor}</span>
                </p>
              </div>

              <div className="bg-white rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Confidence Score</p>
                <p className="text-3xl font-bold text-gray-900">
                  {result.confidence.toFixed(1)}%
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Processing Time</p>
                <p className="font-semibold text-gray-900">{result.processingTime}ms</p>
              </div>
              <div>
                <p className="text-gray-600">Image Quality</p>
                <p className="font-semibold text-gray-900">
                  {result.imageQuality.toFixed(1)}%
                </p>
              </div>
            </div>
          </div>
        )}

        {imagePreview && !result && (
          <button
            onClick={handleAnalyze}
            disabled={processing || !patientName}
            className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-300 text-white font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            {processing ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Analyzing Blood Sample...
              </>
            ) : (
              <>
                <ImageIcon className="w-5 h-5" />
                Analyze Blood Sample
              </>
            )}
          </button>
        )}

        {result && (
          <button
            onClick={handleReset}
            className="w-full bg-gray-600 hover:bg-gray-700 text-white font-medium py-3 rounded-lg transition-colors"
          >
            Analyze Another Sample
          </button>
        )}
      </div>
    </div>
  );
};
