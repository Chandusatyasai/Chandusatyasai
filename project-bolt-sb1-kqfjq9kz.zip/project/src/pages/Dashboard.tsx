import { useState } from 'react';
import { Header } from '../components/Dashboard/Header';
import { DetectionForm } from '../components/Detection/DetectionForm';
import { DetectionHistory } from '../components/History/DetectionHistory';
import { AnalyticsDashboard } from '../components/Analytics/AnalyticsDashboard';

export const Dashboard = () => {
  const [refreshKey, setRefreshKey] = useState(0);

  const handleDetectionComplete = () => {
    setRefreshKey(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Welcome to Blood Group Detection System
          </h2>
          <p className="text-gray-600">
            Upload blood sample images for AI-powered analysis and instant blood group detection
          </p>
        </div>

        <AnalyticsDashboard refresh={refreshKey} />

        <div className="grid lg:grid-cols-2 gap-6 mt-8">
          <DetectionForm onDetectionComplete={handleDetectionComplete} />
          <DetectionHistory refresh={refreshKey} />
        </div>
      </main>
    </div>
  );
};
