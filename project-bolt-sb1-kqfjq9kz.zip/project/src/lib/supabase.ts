import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  full_name: string;
  role: 'admin' | 'doctor' | 'lab_technician' | 'user';
  organization: string | null;
  created_at: string;
  updated_at: string;
};

export type BloodDetection = {
  id: string;
  user_id: string;
  patient_name: string;
  patient_age: number | null;
  patient_gender: 'male' | 'female' | 'other' | null;
  image_url: string;
  blood_group: 'A' | 'B' | 'AB' | 'O' | 'Unknown';
  rh_factor: '+' | '-' | 'Unknown';
  confidence_score: number;
  processing_time_ms: number;
  notes: string | null;
  status: 'pending' | 'completed' | 'verified' | 'rejected';
  verified_by: string | null;
  verified_at: string | null;
  created_at: string;
};

export type DetectionMetadata = {
  id: string;
  detection_id: string;
  image_quality_score: number;
  preprocessing_steps: string[];
  model_version: string;
  feature_vectors: Record<string, number>;
  created_at: string;
};
