-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('admin', 'doctor', 'lab_technician', 'user')),
  organization text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create blood_detections table
CREATE TABLE IF NOT EXISTS blood_detections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  patient_name text NOT NULL,
  patient_age integer CHECK (patient_age > 0 AND patient_age < 150),
  patient_gender text CHECK (patient_gender IN ('male', 'female', 'other')),
  image_url text NOT NULL,
  blood_group text NOT NULL CHECK (blood_group IN ('A', 'B', 'AB', 'O', 'Unknown')),
  rh_factor text NOT NULL CHECK (rh_factor IN ('+', '-', 'Unknown')),
  confidence_score decimal(5,2) CHECK (confidence_score >= 0 AND confidence_score <= 100),
  processing_time_ms integer DEFAULT 0,
  notes text,
  status text NOT NULL DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'verified', 'rejected')),
  verified_by uuid REFERENCES auth.users(id),
  verified_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Create detection_metadata table
CREATE TABLE IF NOT EXISTS detection_metadata (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  detection_id uuid NOT NULL REFERENCES blood_detections(id) ON DELETE CASCADE,
  image_quality_score decimal(5,2) CHECK (image_quality_score >= 0 AND image_quality_score <= 100),
  preprocessing_steps jsonb DEFAULT '[]'::jsonb,
  model_version text DEFAULT 'v1.0.0',
  feature_vectors jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_blood_detections_user_id ON blood_detections(user_id);
CREATE INDEX IF NOT EXISTS idx_blood_detections_status ON blood_detections(status);
CREATE INDEX IF NOT EXISTS idx_blood_detections_created_at ON blood_detections(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_detection_metadata_detection_id ON detection_metadata(detection_id);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE blood_detections ENABLE ROW LEVEL SECURITY;
ALTER TABLE detection_metadata ENABLE ROW LEVEL SECURITY;

-- Profiles policies
DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Blood detections policies
DROP POLICY IF EXISTS "Users can view own detections" ON blood_detections;
CREATE POLICY "Users can view own detections"
  ON blood_detections FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can create own detections" ON blood_detections;
CREATE POLICY "Users can create own detections"
  ON blood_detections FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own detections" ON blood_detections;
CREATE POLICY "Users can update own detections"
  ON blood_detections FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can delete own detections" ON blood_detections;
CREATE POLICY "Users can delete own detections"
  ON blood_detections FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Detection metadata policies
DROP POLICY IF EXISTS "Users can view metadata for own detections" ON detection_metadata;
CREATE POLICY "Users can view metadata for own detections"
  ON detection_metadata FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM blood_detections
      WHERE blood_detections.id = detection_metadata.detection_id
      AND blood_detections.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Users can create metadata for own detections" ON detection_metadata;
CREATE POLICY "Users can create metadata for own detections"
  ON detection_metadata FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM blood_detections
      WHERE blood_detections.id = detection_metadata.detection_id
      AND blood_detections.user_id = auth.uid()
    )
  );
